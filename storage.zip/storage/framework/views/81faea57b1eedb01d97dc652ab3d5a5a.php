<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $currentTab;

    public $editingStepId;

    public $editStepName;

    public $editDeadline;

    public $showEditModal;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function pendingAgendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('pendingAgendas'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function ongoingAgendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('ongoingAgendas'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function completedAgendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('completedAgendas'))->execute(...$arguments);
    }

    public function editStep($stepId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('editStep'))->execute(...$arguments);
    }

    public function saveAdjustment()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('saveAdjustment'))->execute(...$arguments);
    }

    public function approve($agendaId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('approve'))->execute(...$arguments);
    }

    public function reject($agendaId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('reject'))->execute(...$arguments);
    }

};