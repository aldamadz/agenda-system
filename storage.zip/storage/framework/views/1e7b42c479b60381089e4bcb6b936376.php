<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $targetDate;

    public $selectedAgendaId;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function selectedAgenda()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('selectedAgenda'))->execute(...$arguments);
    }

    public function nextMonth()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('nextMonth'))->execute(...$arguments);
    }

    public function prevMonth()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('prevMonth'))->execute(...$arguments);
    }

    public function showDetail($id)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('showDetail'))->execute(...$arguments);
    }

    public function getDays()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('getDays'))->execute(...$arguments);
    }

};