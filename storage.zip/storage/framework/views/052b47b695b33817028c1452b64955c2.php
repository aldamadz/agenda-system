<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    use Livewire\WithFileUploads;

    public $showNoteModal;

    public $editingStepId;

    public $stepNote;

    public $attachment;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function monitoringAgendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('monitoringAgendas'))->execute(...$arguments);
    }

    public function clickStep($stepId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('clickStep'))->execute(...$arguments);
    }

    public function saveStepCompletion()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('saveStepCompletion'))->execute(...$arguments);
    }

    public function completeAgenda($id)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('completeAgenda'))->execute(...$arguments);
    }

    public function cancelCompletion()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('cancelCompletion'))->execute(...$arguments);
    }

    public function updateStepDeadline($stepId, $value)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('updateStepDeadline'))->execute(...$arguments);
    }

    public function rejectAgenda($id)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('rejectAgenda'))->execute(...$arguments);
    }

};