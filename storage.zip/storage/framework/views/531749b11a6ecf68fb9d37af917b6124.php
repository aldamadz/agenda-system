<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    use Livewire\WithPagination;

    public $search;

    public $date_from;

    public $date_to;

    public $showModal;

    public $selectedLog;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    public function openDetail($logId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('openDetail'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function logs()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('logs'))->execute(...$arguments);
    }

    public function updating($name)
    {
        $arguments = [static::$__context, $this, array_slice(func_get_args(), 1)];

        return (new Actions\CallPropertyHook('updating', $name))->execute(...$arguments);
    }

};