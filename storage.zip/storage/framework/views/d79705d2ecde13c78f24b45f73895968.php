<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $showApprovalDetailModal;

    public $showNoteModal;

    public $selectedAgenda;

    public $editingStepId;

    public $stepNote;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function stats()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('stats'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function pendingAgendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('pendingAgendas'))->execute(...$arguments);
    }

    #[\Livewire\Attributes\Computed()]
    public function monitoringAgendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('monitoringAgendas'))->execute(...$arguments);
    }

    public function viewDetail($id)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('viewDetail'))->execute(...$arguments);
    }

    public function approve($id)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('approve'))->execute(...$arguments);
    }

    public function reject($id)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('reject'))->execute(...$arguments);
    }

    public function clickStep($stepId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('clickStep'))->execute(...$arguments);
    }

    public function saveStepCompletion()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('saveStepCompletion'))->execute(...$arguments);
    }

};