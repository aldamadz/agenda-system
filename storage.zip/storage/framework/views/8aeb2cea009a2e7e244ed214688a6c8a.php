<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $activeStepId;

    public $stepNote;

    public $showNoteModal;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function agendas()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('agendas'))->execute(...$arguments);
    }

    public function prepareToggle($stepId, $isCurrentlyCompleted)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('prepareToggle'))->execute(...$arguments);
    }

    public function saveStepWithNote()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('saveStepWithNote'))->execute(...$arguments);
    }

    public function finishAgenda($agendaId)
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('finishAgenda'))->execute(...$arguments);
    }

};