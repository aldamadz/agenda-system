<?php

use Livewire\Volt\Actions;
use Livewire\Volt\CompileContext;
use Livewire\Volt\Contracts\Compiled;
use Livewire\Volt\Component;

new class extends Component implements Livewire\Volt\Contracts\FunctionalComponent
{
    public static CompileContext $__context;

    use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

    public $filter_type;

    public $selected_date;

    public $date_from;

    public $date_to;

    public function mount()
    {
        (new Actions\InitializeState)->execute(static::$__context, $this, get_defined_vars());

        (new Actions\CallHook('mount'))->execute(static::$__context, $this, get_defined_vars());
    }

    #[\Livewire\Attributes\Computed()]
    public function getStats()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallMethod('getStats'))->execute(...$arguments);
    }

    public function getListeners()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\ResolveListeners)->execute(...$arguments);
    }

    public function refreshStatsHandler()
    {
        $arguments = [static::$__context, $this, func_get_args()];

        return (new Actions\CallListener('refresh-stats'))->execute(...$arguments);
    }

};