<?php

use App\Models\Agenda;
use Livewire\WithPagination;

?>

<div class="p-6 lg:p-10 space-y-10">
    
    <div
        class="flex flex-col lg:flex-row lg:items-center justify-between gap-8 border-b border-slate-200 dark:border-white/10 pb-10">
        <div class="space-y-2">
            <div class="flex items-center gap-3">
                <span class="h-1.5 w-10 bg-emerald-500 rounded-full animate-pulse"></span>
                <span class="text-[10px] font-black uppercase tracking-[0.4em] text-emerald-500">Vault System</span>
            </div>
            <h1
                class="text-5xl font-black text-slate-900 dark:text-white tracking-tighter uppercase italic leading-none">
                Riwayat <span class="text-emerald-500">Selesai</span>
            </h1>
            <p class="text-slate-500 font-bold text-sm tracking-tight uppercase opacity-70">
                Arsip Terenkripsi: <?php echo e($this->historyAgendas->total()); ?> Dokumen Ditemukan
            </p>
        </div>

        
        <div class="w-full lg:w-96 relative group">
            <div
                class="absolute inset-y-0 left-5 flex items-center pointer-events-none text-slate-400 group-focus-within:text-emerald-500 transition-colors duration-300">
                <?php if (isset($component)) { $__componentOriginalc3d062a579167d374258253d48d4177f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3d062a579167d374258253d48d4177f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.magnifying-glass','data' => ['variant' => 'micro','class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.magnifying-glass'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'micro','class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3d062a579167d374258253d48d4177f)): ?>
<?php $attributes = $__attributesOriginalc3d062a579167d374258253d48d4177f; ?>
<?php unset($__attributesOriginalc3d062a579167d374258253d48d4177f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3d062a579167d374258253d48d4177f)): ?>
<?php $component = $__componentOriginalc3d062a579167d374258253d48d4177f; ?>
<?php unset($__componentOriginalc3d062a579167d374258253d48d4177f); ?>
<?php endif; ?>
            </div>
            <input wire:model.live.debounce.300ms="search" type="text" placeholder="Cari arsip agenda..."
                class="w-full pl-14 pr-6 py-5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-[2rem] text-sm font-black tracking-tight focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500/50 transition-all duration-300 outline-none shadow-sm">
        </div>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->historyAgendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agenda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div
                class="group relative flex flex-col justify-between p-8 rounded-[3rem]
                       bg-white/60 dark:bg-slate-900/40 border border-white/20 dark:border-white/5 backdrop-blur-sm shadow-xl
                       /* OPTIMASI ANIMASI SMOOTH */
                       transition-[transform,box-shadow,background-color] duration-500 ease-[cubic-bezier(0.34,1.56,0.64,1)]
                       hover:scale-[1.03] hover:shadow-2xl hover:shadow-emerald-500/15 hover:bg-white dark:hover:bg-slate-800/60
                       will-change-transform transform-gpu">
                
                <div
                    class="absolute -right-6 -top-6 opacity-[0.03] group-hover:opacity-[0.08] group-hover:rotate-[25deg] group-hover:scale-125 transition-all duration-1000 ease-out pointer-events-none">
                    <?php if (isset($component)) { $__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.check-badge','data' => ['variant' => 'solid','class' => 'w-48 h-48 text-emerald-500']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.check-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'solid','class' => 'w-48 h-48 text-emerald-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb)): ?>
<?php $attributes = $__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb; ?>
<?php unset($__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb)): ?>
<?php $component = $__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb; ?>
<?php unset($__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb); ?>
<?php endif; ?>
                </div>

                <div class="relative z-10">
                    <div class="flex justify-between items-start mb-8">
                        <div
                            class="w-14 h-14 bg-emerald-500 text-white rounded-[1.5rem] flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:rotate-6 transition-transform duration-500">
                            <?php if (isset($component)) { $__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.check-badge','data' => ['variant' => 'solid','class' => 'w-8 h-8']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.check-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'solid','class' => 'w-8 h-8']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb)): ?>
<?php $attributes = $__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb; ?>
<?php unset($__attributesOriginaldb480e8d5d7476402b0c7e6f30ee2bdb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb)): ?>
<?php $component = $__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb; ?>
<?php unset($__componentOriginaldb480e8d5d7476402b0c7e6f30ee2bdb); ?>
<?php endif; ?>
                        </div>
                        <div class="text-right">
                            <span
                                class="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">Entry
                                ID</span>
                            <span
                                class="text-xs font-black text-slate-900 dark:text-white">#ARCHV-<?php echo e($agenda->id); ?></span>
                        </div>
                    </div>

                    <h3
                        class="text-2xl font-black text-slate-900 dark:text-white leading-[1.1] tracking-tighter mb-4 group-hover:text-emerald-500 transition-colors duration-300 uppercase italic">
                        <?php echo e($agenda->title); ?>

                    </h3>

                    <div class="flex flex-col gap-2 mb-8">
                        <div class="flex items-center gap-2">
                            <span class="h-1 w-1 rounded-full bg-emerald-500"></span>
                            <span
                                class="text-[11px] font-black text-indigo-500 uppercase tracking-tight"><?php echo e($agenda->user->name); ?></span>
                        </div>
                        <div class="flex items-center gap-2">
                            <span class="h-1 w-1 rounded-full bg-slate-300"></span>
                            <span
                                class="text-[10px] font-bold text-slate-400 uppercase flex items-center gap-1.5 italic">
                                <?php if (isset($component)) { $__componentOriginalf48bb55ce6fd23a8de595ceefa5f14db = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf48bb55ce6fd23a8de595ceefa5f14db = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.calendar','data' => ['variant' => 'micro','class' => 'w-3.5 h-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.calendar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'micro','class' => 'w-3.5 h-3.5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf48bb55ce6fd23a8de595ceefa5f14db)): ?>
<?php $attributes = $__attributesOriginalf48bb55ce6fd23a8de595ceefa5f14db; ?>
<?php unset($__attributesOriginalf48bb55ce6fd23a8de595ceefa5f14db); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf48bb55ce6fd23a8de595ceefa5f14db)): ?>
<?php $component = $__componentOriginalf48bb55ce6fd23a8de595ceefa5f14db; ?>
<?php unset($__componentOriginalf48bb55ce6fd23a8de595ceefa5f14db); ?>
<?php endif; ?>
                                <?php echo e($agenda->updated_at->translatedFormat('d M Y')); ?>

                            </span>
                        </div>
                    </div>

                    
                    <div class="space-y-3 mb-4">
                        <div
                            class="flex justify-between text-[9px] font-black uppercase text-slate-400 tracking-[0.2em]">
                            <span>Completed Steps</span>
                            <span class="text-emerald-500"><?php echo e($agenda->steps->count()); ?> Data Points</span>
                        </div>
                        <div
                            class="h-2 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden flex gap-0.5 p-0.5">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $agenda->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    class="h-full flex-1 bg-emerald-500 rounded-full shadow-[0_0_12px_rgba(16,185,129,0.4)] transition-all group-hover:brightness-110">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="relative z-10 mt-auto">
                    <button wire:click="openDetail(<?php echo e($agenda->id); ?>)"
                        class="w-full bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-[11px] font-black uppercase py-5 rounded-2xl tracking-[0.3em]
                               transition-all duration-300 hover:bg-emerald-500 hover:text-white dark:hover:bg-emerald-500 dark:hover:text-white hover:shadow-lg hover:shadow-emerald-500/20 active:scale-95">
                        Buka Arsip Detail
                    </button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div
                class="col-span-full py-32 flex flex-col items-center justify-center glass-card rounded-[4rem] border-dashed border-slate-300 dark:border-white/10 text-center animate-in fade-in zoom-in duration-700">
                <div class="w-24 h-24 bg-slate-50 dark:bg-white/5 rounded-full flex items-center justify-center mb-8">
                    <?php if (isset($component)) { $__componentOriginalc3d062a579167d374258253d48d4177f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3d062a579167d374258253d48d4177f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.magnifying-glass','data' => ['class' => 'w-12 h-12 text-slate-200 dark:text-white/10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.magnifying-glass'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-12 h-12 text-slate-200 dark:text-white/10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3d062a579167d374258253d48d4177f)): ?>
<?php $attributes = $__attributesOriginalc3d062a579167d374258253d48d4177f; ?>
<?php unset($__attributesOriginalc3d062a579167d374258253d48d4177f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3d062a579167d374258253d48d4177f)): ?>
<?php $component = $__componentOriginalc3d062a579167d374258253d48d4177f; ?>
<?php unset($__componentOriginalc3d062a579167d374258253d48d4177f); ?>
<?php endif; ?>
                </div>
                <h3 class="text-3xl font-black text-slate-900 dark:text-white tracking-tighter uppercase italic">Data
                    Kosong</h3>
                <p class="text-slate-400 font-bold uppercase text-xs tracking-widest mt-2">Tidak ditemukan hasil untuk
                    "<?php echo e($this->search); ?>"</p>
            </div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>

    
    <div class="pt-12 border-t border-slate-200 dark:border-white/10">
        <?php echo e($this->historyAgendas->links()); ?>

    </div>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedAgenda): ?>
        <?php if (isset($component)) { $__componentOriginal8cc9d3143946b992b324617832699c5f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8cc9d3143946b992b324617832699c5f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.index','data' => ['wire:model' => 'showModal','class' => '!bg-slate-50/98 dark:!bg-slate-900/98 backdrop-blur-3xl border-white/20 rounded-[4rem] md:w-[800px] !p-0 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model' => 'showModal','class' => '!bg-slate-50/98 dark:!bg-slate-900/98 backdrop-blur-3xl border-white/20 rounded-[4rem] md:w-[800px] !p-0 shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300']); ?>
            <div class="p-12 space-y-10">
                <div class="flex justify-between items-start">
                    <div class="space-y-3">
                        <div class="flex items-center gap-2">
                            <span
                                class="px-4 py-1.5 bg-emerald-500/10 text-emerald-500 text-[10px] font-black rounded-full uppercase tracking-widest border border-emerald-500/20 shadow-sm">Verified
                                Report</span>
                        </div>
                        <h2
                            class="text-5xl font-black text-slate-900 dark:text-white tracking-tighter uppercase italic leading-none">
                            <?php echo e($selectedAgenda->title); ?></h2>
                    </div>
                    <button wire:click="$set('showModal', false)"
                        class="p-4 bg-white dark:bg-white/5 hover:bg-red-500 hover:text-white rounded-3xl transition-all duration-300 shadow-sm active:scale-90">
                        <?php if (isset($component)) { $__componentOriginal155e76c41fe51242bc25d269fabf82f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal155e76c41fe51242bc25d269fabf82f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.x-mark','data' => ['class' => 'w-6 h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.x-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal155e76c41fe51242bc25d269fabf82f5)): ?>
<?php $attributes = $__attributesOriginal155e76c41fe51242bc25d269fabf82f5; ?>
<?php unset($__attributesOriginal155e76c41fe51242bc25d269fabf82f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal155e76c41fe51242bc25d269fabf82f5)): ?>
<?php $component = $__componentOriginal155e76c41fe51242bc25d269fabf82f5; ?>
<?php unset($__componentOriginal155e76c41fe51242bc25d269fabf82f5); ?>
<?php endif; ?>
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="p-8 bg-white dark:bg-white/5 rounded-[2.5rem] border border-white/20 shadow-sm">
                        <span
                            class="text-[11px] font-black text-indigo-500 uppercase tracking-[0.2em] block mb-3">Responsible
                            Officer</span>
                        <p class="text-2xl font-black text-slate-800 dark:text-white tracking-tight leading-none">
                            <?php echo e($selectedAgenda->user->name); ?></p>
                    </div>
                    <div class="p-8 bg-white dark:bg-white/5 rounded-[2.5rem] border border-white/20 shadow-sm">
                        <span
                            class="text-[11px] font-black text-emerald-500 uppercase tracking-[0.2em] block mb-3">Completion
                            Date</span>
                        <p class="text-2xl font-black text-slate-800 dark:text-white tracking-tight leading-none">
                            <?php echo e($selectedAgenda->updated_at->translatedFormat('d F Y')); ?></p>
                    </div>
                </div>

                <div class="space-y-6">
                    <div class="flex items-center gap-5">
                        <span class="text-xs font-black uppercase tracking-[0.4em] text-slate-400">Activity
                            Sequence</span>
                        <div class="flex-1 h-[2px] bg-slate-200 dark:bg-white/10 rounded-full"></div>
                    </div>

                    <div class="space-y-4 max-h-[400px] overflow-y-auto pr-4 custom-scrollbar">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $selectedAgenda->steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div x-data="{ open: false }"
                                class="bg-white/50 dark:bg-white/5 border border-white/10 rounded-[2rem] overflow-hidden transition-all duration-300 hover:border-emerald-500/30">
                                <button @click="open = !open" type="button"
                                    class="w-full flex items-center gap-6 p-6 text-left group">
                                    <div
                                        class="w-12 h-12 rounded-2xl bg-emerald-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20 shrink-0 group-hover:scale-110 transition-transform">
                                        <?php if (isset($component)) { $__componentOriginal99e1287553cbf55f278732425b3f00bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal99e1287553cbf55f278732425b3f00bd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.check-circle','data' => ['variant' => 'solid','class' => 'w-6 h-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.check-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'solid','class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal99e1287553cbf55f278732425b3f00bd)): ?>
<?php $attributes = $__attributesOriginal99e1287553cbf55f278732425b3f00bd; ?>
<?php unset($__attributesOriginal99e1287553cbf55f278732425b3f00bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99e1287553cbf55f278732425b3f00bd)): ?>
<?php $component = $__componentOriginal99e1287553cbf55f278732425b3f00bd; ?>
<?php unset($__componentOriginal99e1287553cbf55f278732425b3f00bd); ?>
<?php endif; ?>
                                    </div>
                                    <div class="flex-1">
                                        <span
                                            class="text-base font-black text-slate-800 dark:text-slate-100 tracking-tight block mb-0.5 leading-tight"><?php echo e($step->step_name); ?></span>
                                        <span
                                            class="text-[10px] font-bold text-slate-400 uppercase italic tracking-tighter">Verified
                                            at: <?php echo e($step->updated_at->format('H:i')); ?> WIB</span>
                                    </div>
                                    <?php if (isset($component)) { $__componentOriginal298ff21bbc41cebb188cbb18c6c11bc0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal298ff21bbc41cebb188cbb18c6c11bc0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.chevron-down','data' => ['class' => 'w-5 h-5 text-slate-400 transition-all duration-500']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.chevron-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('w-5 h-5 text-slate-400 transition-all duration-500')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal298ff21bbc41cebb188cbb18c6c11bc0)): ?>
<?php $attributes = $__attributesOriginal298ff21bbc41cebb188cbb18c6c11bc0; ?>
<?php unset($__attributesOriginal298ff21bbc41cebb188cbb18c6c11bc0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal298ff21bbc41cebb188cbb18c6c11bc0)): ?>
<?php $component = $__componentOriginal298ff21bbc41cebb188cbb18c6c11bc0; ?>
<?php unset($__componentOriginal298ff21bbc41cebb188cbb18c6c11bc0); ?>
<?php endif; ?>
                                </button>

                                <div x-show="open" x-collapse x-cloak class="px-6 pb-6">
                                    <div
                                        class="p-6 bg-slate-100 dark:bg-black/30 rounded-[2rem] border-l-[6px] border-emerald-500 space-y-4">
                                        <div>
                                            <span
                                                class="text-[10px] font-black text-emerald-500 uppercase block mb-2 tracking-[0.2em]">Penyelesaian
                                                Dokumen:</span>
                                            <p
                                                class="text-sm text-slate-600 dark:text-slate-400 leading-relaxed font-bold italic opacity-80">
                                                "<?php echo e($step->notes ?? 'Pekerjaan selesai tanpa anomali catatan.'); ?>"</p>
                                        </div>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($step->attachment): ?>
                                            <a href="<?php echo e(asset('storage/' . $step->attachment)); ?>" target="_blank"
                                                class="inline-flex items-center gap-3 text-[10px] font-black text-white bg-slate-900 dark:bg-indigo-600 px-6 py-4 rounded-2xl hover:scale-105 active:scale-95 transition-all shadow-xl uppercase tracking-widest">
                                                <?php if (isset($component)) { $__componentOriginal770d82aa4e9895cad3421b0fdbed737b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal770d82aa4e9895cad3421b0fdbed737b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::icon.paper-clip','data' => ['variant' => 'micro']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::icon.paper-clip'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'micro']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal770d82aa4e9895cad3421b0fdbed737b)): ?>
<?php $attributes = $__attributesOriginal770d82aa4e9895cad3421b0fdbed737b; ?>
<?php unset($__attributesOriginal770d82aa4e9895cad3421b0fdbed737b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal770d82aa4e9895cad3421b0fdbed737b)): ?>
<?php $component = $__componentOriginal770d82aa4e9895cad3421b0fdbed737b; ?>
<?php unset($__componentOriginal770d82aa4e9895cad3421b0fdbed737b); ?>
<?php endif; ?> Lihat Dokumen Bukti
                                            </a>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                </div>

                <div class="flex justify-end pt-4">
                    <button wire:click="$set('showModal', false)"
                        class="w-full md:w-auto px-16 py-5 bg-emerald-500 text-white rounded-[2rem] text-xs font-black uppercase tracking-[0.4em] shadow-2xl shadow-emerald-500/30 hover:bg-emerald-600 transition-all active:scale-95">
                        Close Archive
                    </button>
                </div>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $attributes = $__attributesOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__attributesOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8cc9d3143946b992b324617832699c5f)): ?>
<?php $component = $__componentOriginal8cc9d3143946b992b324617832699c5f; ?>
<?php unset($__componentOriginal8cc9d3143946b992b324617832699c5f); ?>
<?php endif; ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <style>
        [x-cloak] {
            display: none !important;
        }

        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: rgba(16, 185, 129, 0.2);
            border-radius: 50px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: rgba(16, 185, 129, 0.5);
        }

        /* Smooth Pagination Fix */
        .pagination span,
        .pagination a {
            border-radius: 1.5rem !important;
            border: none !important;
            font-weight: 900 !important;
            font-size: 11px !important;
            text-transform: uppercase !important;
            letter-spacing: 0.1em;
            padding: 12px 20px !important;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1) !important;
        }
    </style>
</div><?php /**PATH C:\laragon\www\agenda-system\resources\views\livewire/dashboard/history-list.blade.php ENDPATH**/ ?>